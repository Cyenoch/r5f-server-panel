import type { NativeCallOptions } from "../native-call";
import type {
  AccessibilityProperties,
  CommandKind,
  CommandPayload,
  CommandValue,
  ExtensionField,
  HostProperties,
  IconName,
} from "../protocol";
import type { ExtensionDescriptor, ExtensionEvent, ExtensionEventHandler } from "./extension";
import type { StyleProp } from "../style";

export type SolidChild =
  | HostNodeInternal
  | (() => SolidChild)
  | string
  | number
  | boolean
  | null
  | undefined
  | readonly SolidChild[];

export interface RootOwner {
  invalid: boolean;
  validationError: Error | undefined;
  submitCommand(node: HostNodeInternal, kind: CommandKind, payload: CommandPayload): Promise<void>;
  submitCommandValue(
    node: HostNodeInternal,
    kind: CommandKind,
    payload: CommandPayload,
    options?: NativeCallOptions,
  ): Promise<CommandValue | null>;
  releaseDetachedFocus(node: HostNodeInternal): void;
  markPropsDirty(node: HostNodeInternal, groups: number): void;
  recordNodeMutation(node: HostNodeInternal): void;
  setNodeProps(node: HostNodeInternal, props: HostProps): void;
  markUpdated(node: HostNodeInternal, mask: number): void;
}
export type HostKind =
  | "View"
  | "Text"
  | "Pressable"
  | "TextInput"
  | "RawText"
  | "VirtualList"
  | "Image"
  | "Extension"
  | "Icon";
export type ImageObjectFit = "fill" | "contain" | "cover" | "scaleDown" | "none";
export type PressEventType = "press";

export interface HostNode {
  readonly id: number;
  readonly kind: HostKind;
}
export interface AccessibilityProps {
  readonly accessibilityRole?:
    | "button"
    | "text"
    | "textbox"
    | "checkbox"
    | "heading"
    | "generic"
    | "link"
    | "status"
    | "alert"
    | "group"
    | "list"
    | "listitem"
    | "dialog";
  readonly accessibilityLabel?: string;
  readonly accessibilityDescription?: string;
  readonly accessibilityDisabled?: boolean;
  readonly accessibilityChecked?: boolean;
  readonly accessibilitySelected?: boolean;
  readonly accessibilityValue?: string;
  readonly accessibilityExpanded?: boolean;
  readonly accessibilityLevel?: number;
  readonly accessibilityLive?: "off" | "polite" | "assertive";
}

export interface TextInputProps extends AccessibilityProps {
  readonly value?: string;
  readonly defaultValue?: string;
  readonly placeholder?: string;
  readonly onChangeText?: (value: string) => void;
  readonly onSelectionChange?: (selection: {
    start: number;
    end: number;
    reversed: boolean;
    composing?: { start: number; end: number } | null;
  }) => void;
  readonly onFocus?: () => void;
  readonly onBlur?: () => void;
  readonly onSubmitEditing?: (value: string) => void;
  readonly onKeyDown?: KeyHandler;
  readonly multiline?: boolean;
  readonly disabled?: boolean;
  readonly maxLength?: number;
  readonly style?: StyleProp;
  readonly children?: SolidChild;
  readonly ref?: (handle: TextInputHandle) => void;
}
export interface TextInputEvent {
  readonly type: "change" | "selection" | "focus" | "blur";
  readonly text: string;
  readonly selection: {
    start: number;
    end: number;
    reversed: boolean;
    composing: { start: number; end: number } | null;
  };
  readonly editSeq: number;
  readonly target: HostNode;
}
export interface TextInputHandle extends HostNode {
  focus(): Promise<void>;
  blur(): Promise<void>;
  setSelection(start: number, end: number): Promise<void>;
}

export interface VirtualListProps<T> extends AccessibilityProps {
  readonly data: readonly T[];
  readonly itemKey: (item: T, index: number) => string | number;
  readonly renderItem: (item: T, index: number) => SolidChild;
  readonly estimatedItemSize: number;
  readonly overscan?: number;
  readonly initialNumToRender?: number;
  readonly onEndReached?: () => void;
  /** Rendered instead of a native VirtualList when `data` is empty. */
  readonly emptyState?: SolidChild;
  readonly style?: StyleProp;
  readonly ref?: (handle: VirtualListHandle) => void;
}
export interface VirtualListHandle extends HostNode {
  scrollToIndex(index: number): Promise<void>;
  scrollToEnd(): Promise<void>;
  getScrollOffset(): Promise<number>;
  scrollToOffset(offset: number): Promise<void>;
}
export interface AnimationCompleteEvent {
  readonly generation: number;
  readonly target: HostNode;
}

/** A press is a semantic notification; native cancellation is intentionally unavailable. */
export interface PressEvent {
  readonly type: PressEventType;
  readonly surfaceId: number;
  readonly epoch: number;
  readonly revision: number;
  readonly sequence: number;
  readonly target: HostNode;
}

export type PressHandler = (event: PressEvent) => void;
export type KeyAction = "down" | "repeat" | "up";
export interface KeyEvent {
  readonly key: string;
  readonly modifiers: string[];
  readonly action: KeyAction;
}
export type KeyHandler = (event: KeyEvent) => void;
export type PointerButton = "left" | "right" | "middle" | "back" | "forward";
export interface PointerEvent {
  readonly type: "pointerdown" | "pointerup";
  readonly button: PointerButton;
  readonly modifiers: string[];
  readonly clickCount: number;
  readonly x: number;
  readonly y: number;
  readonly target: HostNode;
}
export interface PointerMoveEvent {
  readonly type: "pointermove";
  readonly x: number;
  readonly y: number;
  readonly modifiers: string[];
  readonly target: HostNode;
}
export interface FocusEvent {
  readonly type: "focus" | "blur";
  readonly target: HostNode;
}
export type FocusHandler = (event: FocusEvent) => void;
export interface PointerDownOutsideEvent {
  readonly x: number;
  readonly y: number;
}
export type PointerDownOutsideHandler = (event: PointerDownOutsideEvent) => void;
export type PointerHandler = (event: PointerEvent) => void;
export type PointerMoveHandler = (event: PointerMoveEvent) => void;
export type HoverHandler = (hovered: boolean) => void;
export interface Draggable {
  readonly type: string;
  readonly data?: unknown;
  readonly exportFiles?: readonly string[];
}
export type DragOverHandler = (dragType: string) => void;
export type DragDropHandler = (dragType: string) => void;
export type ExternalFileDropHandler = (paths: string[]) => void;
export interface ViewHandle extends HostNode {
  focus(): Promise<void>;
  blur(): Promise<void>;
  isFocused(): Promise<boolean>;
}
export type ScrollDeltaKind = "pixels" | "lines";
export interface ScrollEvent {
  readonly deltaKind: ScrollDeltaKind;
  readonly dx: number;
  readonly dy: number;
  readonly x: number;
  readonly y: number;
  readonly modifiers: string[];
}
export type WindowResizeHandler = (width: number, height: number, scaleFactor?: number) => void;
export type WindowActivationHandler = (active: boolean) => void;
export interface NotificationResponse {
  readonly tag: string;
  readonly actionId: string | null;
}
export type NotificationResponseHandler = (response: NotificationResponse) => void;
export type ScrollHandler = (event: ScrollEvent) => void;
export interface LayoutFrame {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}
export type LayoutHandler = (frame: LayoutFrame) => void;
export type MenuItem =
  | { readonly type: "separator" }
  | { readonly type: "action"; readonly name: string; readonly disabled?: boolean; readonly checked?: boolean }
  | { readonly type: "submenu"; readonly title: string; readonly items: readonly MenuItem[] };
export interface MenuDefinition {
  readonly title: string;
  readonly items: readonly MenuItem[];
}
export interface Keybinding {
  readonly keystrokes: string;
  readonly actionName: string;
}
export interface ViewProps extends AccessibilityProps {
  readonly style?: StyleProp;
  readonly tooltip?: string;
  readonly focusable?: boolean;
  readonly onKeyDown?: KeyHandler;
  readonly onPointerDown?: PointerHandler;
  readonly onPointerUp?: PointerHandler;
  readonly onPointerMove?: PointerMoveHandler;
  readonly onHoverChange?: HoverHandler;
  readonly onFocus?: FocusHandler;
  readonly onBlur?: FocusHandler;
  readonly onPointerDownOutside?: PointerDownOutsideHandler;
  readonly onScroll?: ScrollHandler;
  readonly onLayout?: LayoutHandler;
  readonly draggable?: Draggable;
  readonly onDragOver?: DragOverHandler;
  readonly onDrop?: DragDropHandler;
  readonly onExternalFileDrop?: ExternalFileDropHandler;
  readonly children?: SolidChild;
}
export interface ImageProps extends AccessibilityProps {
  /** Local path, file: URL (native), HTTP(S) URL, or data:image/... URL; at most 1 MiB of UTF-8. */
  readonly source: string;
  /** Image source displayed when the primary fails, using the same supported source formats. */
  readonly fallbackSource?: string;
  readonly objectFit?: ImageObjectFit;
  readonly style?: StyleProp;
  readonly onLayout?: LayoutHandler;
  readonly children?: never;
}
export interface IconProps extends AccessibilityProps {
  readonly name: IconName;
  readonly size?: number;
  readonly color?: string;
  readonly style?: StyleProp;
  readonly onLayout?: LayoutHandler;
  readonly children?: never;
}
export interface TextProps extends AccessibilityProps {
  readonly style?: StyleProp;
  readonly selectable?: boolean;
  readonly onPress?: PressHandler;
  readonly onFocus?: FocusHandler;
  readonly onBlur?: FocusHandler;
  readonly onLayout?: LayoutHandler;
  readonly children?: SolidChild;
}
export interface PressableProps extends AccessibilityProps {
  readonly style?: StyleProp;
  readonly tooltip?: string;
  readonly onPress?: PressHandler;
  readonly focusable?: boolean;
  readonly onKeyDown?: KeyHandler;
  readonly disabled?: boolean;
  readonly onLayout?: LayoutHandler;
  readonly draggable?: Draggable;
  readonly onDragOver?: DragOverHandler;
  readonly onDrop?: DragDropHandler;
  readonly onExternalFileDrop?: ExternalFileDropHandler;
  readonly onPointerDown?: PointerHandler;
  readonly onPointerUp?: PointerHandler;
  readonly onPointerMove?: PointerMoveHandler;
  readonly onHoverChange?: HoverHandler;
  readonly onFocus?: FocusHandler;
  readonly onBlur?: FocusHandler;
  readonly children?: SolidChild;
}
export interface ExtensionPropsBase extends AccessibilityProps {
  readonly style?: StyleProp;
  readonly children?: SolidChild;
  readonly onExtensionEvent?: ExtensionEventHandler;
  readonly onLayout?: LayoutHandler;
  readonly __extensionDescriptor?: ExtensionDescriptor;
  readonly __extensionProps?: Record<string, unknown>;
}
export type ExtensionComponentProps<Props extends object> = ExtensionPropsBase & Props;
export interface HostProps extends AccessibilityProps {
  readonly style?: StyleProp;
  readonly tooltip?: string;
  readonly onPress?: PressHandler;
  readonly focusable?: boolean;
  readonly selectable?: boolean;
  readonly onKeyDown?: KeyHandler;
  readonly disabled?: boolean;
  readonly onPointerDown?: PointerHandler;
  readonly onPointerUp?: PointerHandler;
  readonly onPointerMove?: PointerMoveHandler;
  readonly onHoverChange?: HoverHandler;
  readonly onFocus?: FocusHandler;
  readonly onBlur?: FocusHandler;
  readonly onPointerDownOutside?: PointerDownOutsideHandler;
  readonly onScroll?: ScrollHandler;
  readonly onSubmitEditing?: (value: string) => void;
  readonly maxLength?: number;
  readonly draggable?: Draggable;
  readonly onDragOver?: DragOverHandler;
  readonly onDrop?: DragDropHandler;
  readonly onExternalFileDrop?: ExternalFileDropHandler;
  readonly source?: string;
  readonly fallbackSource?: string;
  readonly objectFit?: ImageObjectFit;
  readonly name?: IconName;
  readonly size?: number;
  readonly color?: string;
  readonly onLayout?: LayoutHandler;
  readonly children?: SolidChild;
  readonly __itemCount?: number;
  readonly __rangeStart?: number;
  readonly __rangeEnd?: number;
  readonly __estimatedItemSize?: number;
  readonly __overscan?: number;
  readonly __onVisibleRange?: (start: number, end: number) => void;
  readonly __onAnimationComplete?: (generation: number) => void;
  readonly __extensionDescriptor?: ExtensionDescriptor;
  readonly __extensionProps?: Record<string, unknown>;
  readonly [key: string]: unknown;
}
export interface PendingCommand {
  readonly identity: import("../native-call").NativeCommandIdentity;
  readonly cleanup: () => void;
  readonly command: CommandKind;
  readonly nodeId: number;
  readonly resolve: (value: CommandValue | null) => void;
  readonly reject: (error: Error) => void;
}
export interface TextInputCallbacks {
  readonly change?: (event: TextInputEvent) => void;
  readonly selection?: (event: TextInputEvent) => void;
  readonly focus?: (event: TextInputEvent) => void;
  readonly blur?: (event: TextInputEvent) => void;
  readonly submit?: (value: string) => void;
}
export interface TextInputCallbackSources {
  readonly change?: TextInputProps["onChangeText"];
  readonly selection?: TextInputProps["onSelectionChange"];
  readonly focus?: TextInputProps["onFocus"];
  readonly blur?: TextInputProps["onBlur"];
  readonly submit?: TextInputProps["onSubmitEditing"];
}
export interface ListenerBinding {
  readonly node: HostNodeInternal;
  readonly listenerId: number;
  revision: number;
  pending: boolean;
  readonly listener: PressHandler | undefined;
  readonly keyListener: KeyHandler | undefined;
  readonly pointerCallbacks: PointerCallbacks | null;
  readonly pointerMoveCallback: PointerMoveHandler | undefined;
  readonly focusCallback: FocusHandler | undefined;
  readonly blurCallback: FocusHandler | undefined;
  readonly pointerDownOutsideCallback: PointerDownOutsideHandler | undefined;
  readonly hoverCallback: HoverHandler | undefined;
  readonly scrollCallback: ScrollHandler | undefined;
  readonly dragCallbacks: DragCallbacks;
  readonly layoutCallback: LayoutHandler | undefined;
  readonly inputCallbacks: TextInputCallbacks | null;
  readonly visibleRangeCallback: ((start: number, end: number) => void) | undefined;
  readonly animationCompleteCallback: ((generation: number) => void) | undefined;
  readonly extensionEventCallback: ExtensionEventHandler | undefined;
  readonly extensionEventIds: readonly number[];
}
export interface PointerCallbacks {
  readonly down?: (event: PointerEvent) => void;
  readonly up?: (event: PointerEvent) => void;
}
export interface DragCallbacks {
  readonly over?: DragOverHandler;
  readonly drop?: DragDropHandler;
  readonly externalFileDrop?: ExternalFileDropHandler;
}
export interface HostNodeInternal extends HostNode {
  readonly root: RootOwner;
  pointerCallbacks: PointerCallbacks | null;
  pointerMoveCallback: PointerMoveHandler | undefined;
  parent: HostNodeInternal | null;
  children: HostNodeInternal[];
  index: number;
  style: StyleProp;
  text: string | null;
  tooltip: string | null;
  acceptsPointerMove: boolean;
  keyListener: KeyHandler | undefined;
  listenerId: number;
  focusCallback: FocusHandler | undefined;
  blurCallback: FocusHandler | undefined;
  detachedFocusPending: boolean;
  nativeFocused: boolean;
  pointerDownOutsideCallback: PointerDownOutsideHandler | undefined;
  hoverCallback: HoverHandler | undefined;
  hovered: boolean;
  scrollCallback: ScrollHandler | undefined;
  listener: PressHandler | undefined;
  focusable: boolean;
  selectable: boolean;
  disabled: boolean;
  focus?: () => Promise<void>;
  dragCallbacks: DragCallbacks;
  hostProperties: HostProperties | null;
  latestNativeText: string | null;
  latestNativeEditSeq: number;
  layoutCallback?: LayoutHandler;
  latestNativeSelection: {
    start: number;
    end: number;
    reversed: boolean;
    markedStart: number | null;
    markedEnd: number | null;
  } | null;
  blur?: () => Promise<void>;
  isFocused?: () => Promise<boolean>;
  setSelection?: (start: number, end: number) => Promise<void>;
  scrollToIndex?: (index: number) => Promise<void>;
  scrollToEnd?: () => Promise<void>;
  getScrollOffset?: () => Promise<number>;
  scrollToOffset?: (offset: number) => Promise<void>;
  inputCallbacks: TextInputCallbacks | null;
  inputCallbackSources: TextInputCallbackSources | null;
  visibleRangeCallback?: (start: number, end: number) => void;
  animationCompleteCallback?: (generation: number) => void;
  extensionEventCallback?: ExtensionEventHandler;
  extensionDescriptor?: ExtensionDescriptor;
  extensionEventIds: readonly number[];
  /** Original Extension props object, retaining Solid getter descriptors. */
  extensionPropsSource?: HostProps;
  lastAnimationGeneration: number | null;
  accessibility: AccessibilityProperties | null;
  attached: boolean;
  props: HostProps;
  mounted: boolean;
}
